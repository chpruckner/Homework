export const USER = [
	{ id: 1, 
	name: "Aleksandar",
	icon: " ",
	active: true,},
	
	{ id: 2, 
	name: "Bettina",
	icon: " ",
	active: true,},
	
	{ id: 3, 
	name: "Catalina",
	icon: " ",
	active: true,},
	
	{ id: 4, 
	name: "Christiane",
	icon: " ",
	active: true,},
	
	{ id: 5, 
	name: "Jeremy",
	icon: " ",
	active: true,},
	
	{ id: 6, 
	name: "Milivoje",
	icon: " ",
	active: true,},
	
	{ id: 7, 
	name: "Vanessa",
	icon: " ",
	active: true,},
	
	{ id: 8, 
	name: "Anamaria",
	icon: " ",
	active: true,},
	
	{ id: 9, 
	name: "Balint",
	icon: " ",
	active: true,},
	
	{ id: 10, 
	name: "Eri",
	icon: " ",
	active: true,},
	
	{ id: 11, 
	name: "Gojart",
	icon: " ",
	active: true,},
	
	{ id: 12, 
	name: "Hadar",
	icon: " ",
	active: true,},
	
	{ id: 13, 
	name: "Jovana",
	icon: " ",
	active: true,},
	
	{ id: 14, 
	name: "Lea",
	icon: " ",
	active: true,},
	
	{ id: 15, 
	name: "Eva",
	icon: " ",
	active: true,},
	
	{ id: 16, 
	name: "Ruba",
	icon: " ",
	active: true,},
	
	{ id: 17, 
	name: "Shabnaz",
	icon: " ",
	active: true,},
	
	{ id: 18, 
	name: "Teofil",
	icon: " ",
	active: true,},
];

export const IMG = 'https://img.icons8.com/ios/50/000000/cat-profile.png';
	